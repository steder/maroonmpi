from mpi import pympi as mpi
mpi.barrier()

mpi.WORLD.barrier()
